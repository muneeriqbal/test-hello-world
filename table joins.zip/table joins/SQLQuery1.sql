create database sms;

use sms;





create table table3(id int primary key ,section varchar(max), branch varchar(max));

create table table2(id2 int primary key ,class int, fee int);

create table table1(S_id int primary key , name varchar(max), gender varchar(max),
idd int foreign key references table3(id) ,fees int foreign key references table2(id2));


select * from table1;
select * from table2;
select * from table3;

insert into table2 values (111,2,1000);
insert into table2 values (112,4,2000);
insert into table2 values (113,5,5000);
insert into table2 values (114,6,7000);

insert into table3 values (1,'A','gul');
insert into table3 values (2,'B','gul');
insert into table3 values (3,'C','f.b.area');


insert into table1 values (11,'ali','M',2,111);
insert into table1 values (12,'zain','M',1,113);
insert into table1 values (13,'husnain','M',2,112);
insert into table1 values (14,'---','F', 3,114);




select *
from table1 
left join  table2 on table1.fees = table2.id2
left join table3  on table1.idd = table3.id order by name asc;